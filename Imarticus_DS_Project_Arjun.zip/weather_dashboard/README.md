
# Imarticus Data Science Internship – Final Project

## 🚀 Project Title:
**Real-Time Weather Dashboard + PDF-Based RAG Chatbot**

## 👨‍💻 Created by:
**Arjun** – Data Analyst Intern

---

## 📌 Project Overview

This project is a full-stack data science application built using Streamlit. It includes:
- 📊 Real-time weather prediction dashboard
- 🤖 Machine learning regression model (trained & deployed)
- 💬 RAG-based chatbot using PDF knowledge base (built with FAISS & HuggingFace)
- 🔍 Interactive visualizations and smart search

---

## 🔧 Tools & Technologies Used

| Component             | Tools/Libraries                        |
|-----------------------|----------------------------------------|
| Language              | Python                                 |
| UI Framework          | Streamlit                              |
| Data Handling         | Pandas, NumPy                          |
| Visualization         | Matplotlib, Plotly                     |
| ML Model              | scikit-learn (regression), joblib      |
| NLP Embeddings        | SentenceTransformers                   |
| Vector Search         | FAISS                                  |
| LLM for QA            | Hugging Face – `google/flan-t5-base`   |
| PDF Parsing           | PyMuPDF                                |

---

## 📁 Folder Structure

```
weather_dashboard/
├── app.py                     # Streamlit dashboard with ML model
├── chatbot.py                 # RAG chatbot Streamlit app
├── generate_index.py          # Embedding + FAISS index creation
├── model.joblib               # Trained regression model
├── faiss_index.idx            # FAISS vector index for chatbot
├── chunks.pkl                 # Stored chunks from PDF
├── docs/
│   ├── combined_text.txt      # Extracted text from PDFs
│   ├── python_cheatsheet.pdf
│   ├── sql_cheatsheet.pdf
│   └── ml_guide.pdf
└── README.md                  # This file
```

---

## 💻 How to Run the App

### Step 1: Install Requirements

```bash
pip install streamlit pandas matplotlib scikit-learn joblib sentence-transformers faiss-cpu transformers pymupdf
```

### Step 2: Run the Dashboard

```bash
streamlit run app.py
```

### Step 3: Run the Chatbot

```bash
streamlit run chatbot.py
```

---

## 📸 Screenshots to Attach

1. 📊 Real-time dashboard view  
2. 📈 ML model prediction chart  
3. 💬 Chatbot interface responding to a question

---

## ✅ Status: Completed  
> All objectives of the internship assessment have been successfully met including real-time predictions, ML model training, PDF-based chatbot, and full UI integration.

---

## 🙌 Thank You!
Special thanks to the Imarticus team for this hands-on internship experience!
